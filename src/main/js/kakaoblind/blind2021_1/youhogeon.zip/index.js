const problem = require("./problem2.js");

problem()